"""
SIMCOM A7670C EFS File Manager
Tested design target: A7670C-LASS / A7670M6_V1.11.1 over USB AT serial port.

Features:
- Detect COM ports and test AT communication
- Browse C:/ files and directories
- Show EFS total / used / free space (AT+FSMEM)
- Upload one or multiple AMR files with progress
- Optional overwrite (deletes same-name file first)
- Delete selected files with confirmation
- Detailed AT log

Install:
    py -m pip install -r requirements.txt
Run:
    py a7670c_efs_manager.py

Notes:
- Select the SIMCom USB AT COM port (not diagnostics/NMEA).
- Uses AT+FSCD, AT+FSLS, AT+FSMEM, AT+FSDEL and AT+CFTRANRX.
- CFTRANRX requires the destination file not to exist. Overwrite mode deletes it first.
- SIMCom's file-transfer guidance recommends 256-byte chunks and about 50 ms delay
  between chunks if transfers fail. Tune only after confirming reliable operation.
- The app uses ASCII-safe destination filenames in C:/.
"""

import os
import re
import sys
import time
import datetime
from pathlib import Path

import serial
from serial.tools import list_ports

from PySide6.QtCore import QThread, Signal, Qt, QSize, QTimer, QEventLoop
from PySide6.QtGui import QIcon, QPixmap, QPainter, QColor, QPen, QFont
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QComboBox, QFileDialog, QTableWidget,
    QTableWidgetItem, QHeaderView, QProgressBar, QPlainTextEdit,
    QMessageBox, QGroupBox, QSpinBox, QCheckBox, QAbstractItemView, QFrame, QSplashScreen, QLineEdit
)


def safe_modem_filename(local_path: str) -> str:
    """Return an ASCII-only filename accepted by the modem EFS."""
    original = Path(local_path).name
    suffix = Path(original).suffix.lower()
    stem = Path(original).stem
    stem = re.sub(r"[^A-Za-z0-9_-]+", "_", stem).strip("._ ")
    if not stem:
        stem = "audio"
    if suffix and not re.fullmatch(r"\.[A-Za-z0-9]{1,8}", suffix):
        suffix = ".amr"
    if not suffix:
        suffix = ".amr"
    return (stem[:60] + suffix)[:72]


class A7670:
    def __init__(self, port: str, baud: int, log):
        self.log = log
        self.ser = serial.Serial(
            port=port,
            baudrate=baud,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=0.10,
            write_timeout=15
        )
        time.sleep(0.25)
        self.ser.reset_input_buffer()
        self.ser.reset_output_buffer()

    def close(self):
        if getattr(self, "ser", None) and self.ser.is_open:
            self.ser.close()

    def _read_until(self, tokens, timeout=10):
        deadline = time.monotonic() + timeout
        data = bytearray()
        while time.monotonic() < deadline:
            b = self.ser.read(1)
            if b:
                data.extend(b)
                upper = bytes(data).upper()
                for token in tokens:
                    if token.upper() in upper:
                        return bytes(data)
            else:
                time.sleep(0.005)
        raise TimeoutError(
            f"Timed out after {timeout}s. Raw response: "
            f"{bytes(data)!r} / {bytes(data).decode('latin-1', errors='replace')}"
        )

    def command(self, cmd: str, timeout=10, allow_error=False) -> str:
        self.ser.reset_input_buffer()
        self.log(f"TX: {cmd}")
        self.ser.write((cmd + "\r\n").encode("ascii"))
        self.ser.flush()
        raw = self._read_until(
            [b"\r\nOK\r\n", b"\nOK\r\n", b"\r\nERROR\r\n",
             b"\nERROR\r\n", b"+CME ERROR:", b"+CMS ERROR:"],
            timeout
        )
        # Some firmware omits the final CRLF after OK/ERROR; collect a short tail.
        time.sleep(0.05)
        tail = self.ser.read_all()
        raw += tail
        response = raw.decode("latin-1", errors="replace")
        self.log("RX: " + response.strip().replace("\r", ""))
        if not allow_error and ("ERROR" in response.upper() or "+CME ERROR" in response.upper()):
            raise RuntimeError(f"{cmd} failed: {response.strip()}")
        return response

    def handshake(self):
        r = self.command("AT", timeout=5)
        if "OK" not in r.upper():
            raise RuntimeError("No AT OK response.")
        ati = self.command("ATI", timeout=8, allow_error=True)
        return ati

    def select_root(self):
        # SIMCom syntax uses an unquoted drive path.
        self.command("AT+FSCD=C:/", timeout=8)

    def list_files(self):
        self.select_root()
        response = self.command("AT+FSLS=2", timeout=15)
        names = []
        in_files = False
        for raw_line in response.replace("\r", "").split("\n"):
            line = raw_line.strip()
            if line.upper().startswith("+FSLS: FILES:"):
                in_files = True
                # A filename may appear on same line on some firmware.
                after = line.split(":", 1)[1].replace("FILES:", "", 1).strip()
                if after:
                    names.append(after)
                continue
            if line.upper().startswith("+FSLS:"):
                in_files = "FILES:" in line.upper()
                continue
            if line.upper() in ("OK", "ERROR") or not line:
                continue
            if in_files and not line.startswith("AT+"):
                names.append(line)
        # Defensive cleanup: strip any duplicate names.
        clean = []
        for name in names:
            name = name.strip().strip('"')
            if name and name not in clean and not name.startswith("+"):
                clean.append(name)
        return clean

    def memory_info(self):
        response = self.command("AT+FSMEM", timeout=10)
        match = re.search(r"\+FSMEM:\s*C:\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)", response, re.I)
        if not match:
            return None
        total, used = map(int, match.groups())
        return total, used, max(0, total - used)

    def delete_file(self, filename):
        # Delete only a single validated basename; never issue wildcard deletion.
        if not filename or filename in (".", "..") or any(c in filename for c in '/\\:*?"<>|'):
            raise ValueError("Unsafe filename; refusing delete.")
        self.select_root()
        return self.command(f'AT+FSDEL="{filename}"', timeout=15)

    def upload_file(self, local_path, overwrite, chunk_size, delay_ms, progress):
        filename = safe_modem_filename(local_path)
        self.select_root()
        existing = self.list_files()
        if filename in existing:
            if not overwrite:
                raise FileExistsError(
                    f"{filename} already exists in C:/. Enable 'Replace existing files' to overwrite it."
                )
            self.log(f"Existing file {filename} found; deleting before upload.")
            self.delete_file(filename)

        total = os.path.getsize(local_path)
        if total <= 0:
            raise ValueError("Selected file is empty.")

        # A full path is required by CFTRANRX. Destination must not already exist.
        destination = "C:/" + filename
        cmd = f'AT+CFTRANRX="{destination}",{total}'
        self.ser.reset_input_buffer()
        self.log(f"TX: {cmd}")
        self.ser.write((cmd + "\r\n").encode("ascii"))
        self.ser.flush()

        # Prompt may be a bare '>' with no CR/LF; detect it byte-by-byte.
        prompt = self._read_until(
            [b">", b"\r\nERROR\r\n", b"\nERROR\r\n", b"+CME ERROR:"],
            timeout=20
        )
        self.log("RX before data: " + prompt.decode("latin-1", errors="replace").strip())
        if b">" not in prompt:
            raise RuntimeError(
                "Modem rejected CFTRANRX before data. Raw response: " +
                prompt.decode("latin-1", errors="replace")
            )

        sent = 0
        start = time.monotonic()
        with open(local_path, "rb") as f:
            while True:
                block = f.read(chunk_size)
                if not block:
                    break
                self.ser.write(block)
                self.ser.flush()
                sent += len(block)
                progress(int(sent * 100 / total))
                if delay_ms:
                    time.sleep(delay_ms / 1000.0)

        # Wait long enough for slower USB transfers / flash writes.
        wait_s = max(45, total / 12000 + 30)
        final = self._read_until(
            [b"\r\nOK\r\n", b"\nOK\r\n", b"\r\nERROR\r\n",
             b"\nERROR\r\n", b"+CME ERROR:"],
            timeout=wait_s
        )
        time.sleep(0.05)
        final += self.ser.read_all()
        final_text = final.decode("latin-1", errors="replace")
        self.log("RX after data: " + final_text.strip().replace("\r", ""))
        if "OK" not in final_text.upper() or "ERROR" in final_text.upper():
            raise RuntimeError("File transfer did not finish successfully: " + final_text.strip())

        elapsed = max(0.001, time.monotonic() - start)
        self.log(f"Uploaded {filename}: {total:,} bytes in {elapsed:.1f}s ({total/elapsed/1024:.1f} KiB/s).")
        progress(100)
        return filename


    def send_sms(self, number: str, message: str, timeout=60):
        number = number.strip()
        if not re.fullmatch(r"\+?[0-9]{5,20}", number):
            raise ValueError("Enter a valid destination number (digits, optional leading +).")
        if not message:
            raise ValueError("SMS message cannot be empty.")
        self.command("AT+CMGF=1", timeout=8)
        self.ser.reset_input_buffer()
        cmd = f'AT+CMGS="{number}"'
        self.log(f"TX: {cmd}")
        self.ser.write((cmd + "\r\n").encode("ascii"))
        self.ser.flush()
        prompt = self._read_until([b">", b"ERROR", b"+CMS ERROR:"], timeout=15)
        self.log("RX: " + prompt.decode("latin-1", errors="replace").strip())
        if b">" not in prompt:
            raise RuntimeError("SMS prompt not received: " + prompt.decode("latin-1", errors="replace"))
        self.ser.write(message.encode("utf-8") + b"\x1a")
        self.ser.flush()
        result = self._read_until([b"\r\nOK\r\n", b"\nOK\r\n", b"+CMS ERROR:", b"\r\nERROR\r\n"], timeout=timeout)
        text = result.decode("latin-1", errors="replace")
        self.log("RX: " + text.strip())
        if "OK" not in text.upper() or "ERROR" in text.upper():
            raise RuntimeError("SMS send failed: " + text.strip())
        return text

    def dial_number(self, number: str):
        number = number.strip()
        if not re.fullmatch(r"\+?[0-9]{5,20}", number):
            raise ValueError("Enter a valid phone number (digits, optional leading +).")
        return self.command(f"ATD{number};", timeout=15, allow_error=True)

    def hangup_call(self):
        return self.command("ATH", timeout=15, allow_error=True)

    def network_snapshot(self):
        commands = [
            "AT+CPIN?", "AT+CSQ", "AT+CEREG?", "AT+CREG?",
            "AT+COPS?", "AT+CPSI?", "AT+CGATT?", "AT+CGDCONT?"
        ]
        output = []
        for cmd in commands:
            try:
                output.append(f"### {cmd}\n{self.command(cmd, timeout=12, allow_error=True).strip()}")
            except Exception as exc:
                output.append(f"### {cmd}\nERROR: {exc}")
        return "\n\n".join(output)



class Job(QThread):
    log = Signal(str)
    status = Signal(str)
    files_ready = Signal(list)
    memory_ready = Signal(object)
    upload_progress = Signal(int)
    item_done = Signal(str, bool, str)
    done = Signal(str, object)
    test_results = Signal(object)

    def __init__(self, port, baud, action, payload=None, overwrite=False,
                 chunk_size=256, delay_ms=50):
        super().__init__()
        self.port = port
        self.baud = baud
        self.action = action
        self.payload = payload
        self.overwrite = overwrite
        self.chunk_size = chunk_size
        self.delay_ms = delay_ms

    def run(self):
        modem = None
        result = None
        error = None
        try:
            self.status.emit("Opening USB AT port...")
            modem = A7670(self.port, self.baud, self.log.emit)
            ati = modem.handshake()
            self.log.emit("Modem identification:\n" + ati.strip())

            if self.action == "connect":
                result = ati
                self.status.emit("AT connection successful")
            elif self.action == "refresh":
                self.status.emit("Reading EFS files...")
                files = modem.list_files()
                mem = modem.memory_info()
                self.files_ready.emit(files)
                self.memory_ready.emit(mem)
                result = files
                self.status.emit(f"Found {len(files)} file(s)")
            elif self.action == "delete":
                names = self.payload or []
                for name in names:
                    modem.delete_file(name)
                    self.item_done.emit(name, True, "Deleted")
                files = modem.list_files()
                mem = modem.memory_info()
                self.files_ready.emit(files)
                self.memory_ready.emit(mem)
                result = files
                self.status.emit("Delete operation completed")
            elif self.action == "upload":
                paths = self.payload or []
                for i, path in enumerate(paths):
                    try:
                        self.status.emit(f"Uploading {Path(path).name} ({i+1}/{len(paths)})")
                        name = modem.upload_file(
                            path, self.overwrite, self.chunk_size, self.delay_ms,
                            self.upload_progress.emit
                        )
                        self.item_done.emit(path, True, f"Uploaded as {name}")
                    except Exception as exc:
                        self.item_done.emit(path, False, str(exc))
                        self.log.emit(f"UPLOAD FAILED: {path}: {exc}")
                        # Continue with the next queued file; each CFTRANRX failure is isolated.
                    self.upload_progress.emit(0)
                files = modem.list_files()
                mem = modem.memory_info()
                self.files_ready.emit(files)
                self.memory_ready.emit(mem)
                result = files
                self.status.emit("Upload queue completed")
            elif self.action == "raw":
                command = str(self.payload or "").strip()
                if not command.upper().startswith("AT"):
                    raise ValueError("AT commands must begin with AT.")
                result = modem.command(command, timeout=20, allow_error=True)
                self.status.emit("AT command completed")
            elif self.action == "send_sms":
                number, message = self.payload
                result = modem.send_sms(number, message)
                self.status.emit("SMS send completed")
            elif self.action == "read_sms":
                modem.command("AT+CMGF=1", timeout=8)
                result = modem.command('AT+CMGL="ALL"', timeout=30, allow_error=True)
                self.status.emit("SMS inbox read completed")
            elif self.action == "dial":
                result = modem.dial_number(str(self.payload))
                self.status.emit("Dial command sent; check call progress / URCs")
            elif self.action == "hangup":
                result = modem.hangup_call()
                self.status.emit("Hang-up command sent")
            elif self.action == "call_status":
                result = modem.command("AT+CLCC", timeout=12, allow_error=True)
                self.status.emit("Call status queried")
            elif self.action == "network":
                result = modem.network_snapshot()
                self.status.emit("Network diagnostics completed")
            elif self.action == "auto_test":
                checks = []
                sequence = [
                    ("AT communication", "AT", lambda r: "OK" in r.upper()),
                    ("Modem identification / firmware", "ATI", lambda r: "ERROR" not in r.upper() and bool(r.strip())),
                    ("IMEI", "AT+CGSN", lambda r: bool(re.search(r"\b\d{14,17}\b", r))),
                    ("SIM readiness", "AT+CPIN?", lambda r: "READY" in r.upper()),
                    ("Signal quality", "AT+CSQ", lambda r: bool(re.search(r"\+CSQ:\s*(?!99,)[0-9]{1,2}\s*,", r))),
                    ("EPS network registration", "AT+CEREG?", lambda r: bool(re.search(r"\+CEREG:\s*\d+\s*,\s*[15](?:\D|$)", r))),
                    ("Circuit network registration", "AT+CREG?", lambda r: bool(re.search(r"\+CREG:\s*\d+\s*,\s*[15](?:\D|$)", r))),
                    ("Operator information", "AT+COPS?", lambda r: "+COPS:" in r.upper() and "ERROR" not in r.upper()),
                    ("Packet service attachment", "AT+CGATT?", lambda r: bool(re.search(r"\+CGATT:\s*1", r))),
                    ("PDP context configuration", "AT+CGDCONT?", lambda r: "+CGDCONT:" in r.upper() and "ERROR" not in r.upper()),
                ]
                for label, cmd, validator in sequence:
                    try:
                        response = modem.command(cmd, timeout=12, allow_error=True)
                        passed = bool(validator(response))
                        detail = "Response received" if passed else response.strip().replace("\r", " ")[-240:]
                        checks.append({"name": label, "command": cmd, "status": "PASS" if passed else "FAIL", "detail": detail})
                    except Exception as exc:
                        checks.append({"name": label, "command": cmd, "status": "FAIL", "detail": str(exc)})
                    self.test_results.emit(list(checks))
                result = checks
                passed_count = sum(1 for x in checks if x["status"] == "PASS")
                self.status.emit(f"Automatic test completed: {passed_count}/{len(checks)} passed")
        except Exception as exc:
            error = str(exc)
            self.log.emit("ERROR: " + error)
            self.status.emit("Operation failed")
        finally:
            if modem:
                modem.close()
                self.log.emit("USB AT port closed.")
            self.done.emit(error or "OK", result)



class AnimatedSplash(QSplashScreen):
    """Short branded startup animation using the supplied UES logo."""
    def __init__(self, logo_path):
        canvas = QPixmap(900, 430)
        canvas.fill(QColor("#061D2A"))
        super().__init__(canvas)
        self.logo = QPixmap(str(logo_path)) if Path(logo_path).exists() else QPixmap()
        self.phase = 0
        self.progress = 0
        self.setFixedSize(900, 430)
        self.setWindowFlag(Qt.WindowStaysOnTopHint, True)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.animate)
        self.timer.start(30)

    def animate(self):
        self.phase = (self.phase + 7) % 360
        self.progress = min(100, self.progress + 2)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(), QColor("#061D2A"))
        glow = 105 + int(65 * (1 + __import__("math").sin(self.phase * 3.14159 / 180)) / 2)
        painter.setPen(QPen(QColor(249, 168, 23, glow), 3))
        painter.drawRoundedRect(12, 12, 876, 406, 14, 14)
        if not self.logo.isNull():
            scaled = self.logo.scaled(820, 285, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            painter.drawPixmap((900-scaled.width())//2, 48, scaled)
        painter.setPen(QColor("#F9A817"))
        painter.setFont(QFont("Segoe UI", 13, QFont.Bold))
        painter.drawText(0, 350, 900, 25, Qt.AlignCenter, "A7670C STUDIO  •  MODEM ENGINEERING TEST SUITE")
        painter.setPen(QColor("#C7D2DC"))
        painter.setFont(QFont("Segoe UI", 9))
        painter.drawText(0, 378, 900, 20, Qt.AlignCenter, "Initializing application components...")
        x, y, w, h = 180, 405, 540, 5
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#243B49"))
        painter.drawRoundedRect(x, y, w, h, 3, 3)
        painter.setBrush(QColor("#F9A817"))
        painter.drawRoundedRect(x, y, int(w*self.progress/100), h, 3, 3)
        painter.end()


class MainWindow(QMainWindow):
    COLORS = {
        "bg": "#F3F6FB", "panel": "#FFFFFF", "nav": "#101B32",
        "nav2": "#172541", "text": "#17243B", "muted": "#7B879B",
        "blue": "#F9A817", "cyan": "#20B7C9", "green": "#18A874",
        "red": "#E05260", "line": "#E6EBF2", "soft": "#FFF4D9"
    }

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Unique Embedded Systems | A7670C Studio v1.2.4")
        from PySide6.QtGui import QIcon
        logo_path = Path(__file__).with_name("Brand_Logo.png")
        icon_path = Path(__file__).with_name("unique_embedded_icon.ico")
        self.setWindowIcon(QIcon(str(logo_path if logo_path.exists() else icon_path)))
        self.resize(1240, 820)
        self.setMinimumSize(1060, 700)
        self.local_files = []
        self.remote_files = []
        self.job = None
        self.current_page = 0
        self.setStyleSheet(self.stylesheet())
        self.build_ui()
        self.refresh_ports()

    @staticmethod
    def svg_icon(name, color="#FFFFFF", size=22):
        paths = {
            "overview": '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
            "folder": '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v8a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/><path d="M3 10h18"/>',
            "upload": '<path d="M12 16V4m0 0L7 9m5-5 5 5"/><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
            "terminal": '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 9 3 3-3 3m6 0h4"/>',
            "settings": '<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.1 1.8-1.8 1.8-1.8-1.1-.2-.1a7.8 7.8 0 0 1-1.5.6l-.5 2.1h-2.6l-.5-2.1a7.8 7.8 0 0 1-1.5-.6l-2 1.1-1.8-1.8 1.1-1.8a7.8 7.8 0 0 1-.6-1.5L3 13v-2l2.2-.5a7.8 7.8 0 0 1 .6-1.5L4.7 7.2 6.5 5.4l1.8 1.1a7.8 7.8 0 0 1 1.5-.6L10.3 3h2.6l.5 2.1a7.8 7.8 0 0 1 1.5.6l1.8-1.1 1.8 1.8-1.1 1.8a7.8 7.8 0 0 1 .6 1.5l2.2.5v2l-2.2.5a7.8 7.8 0 0 1-.6 1.5Z"/>',
            "refresh": '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.5 9A7 7 0 0 1 18 6l2 2M4 16l2 2a7 7 0 0 0 12.5-3"/>',
            "trash": '<path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3"/>',
            "check": '<path d="m5 12 4 4L19 6"/>',
            "plug": '<path d="M9 7V3m6 4V3M7 7h10v5a5 5 0 0 1-10 0zM12 17v4"/>',
            "music": '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
            "file": '<path d="M13 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10z"/><path d="M13 3v7h7"/>',
        }
        svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">{paths.get(name, paths["file"])}</svg>'
        from PySide6.QtGui import QPixmap, QIcon
        from PySide6.QtSvg import QSvgRenderer
        from PySide6.QtCore import QByteArray
        pix = QPixmap(size, size)
        pix.fill(Qt.transparent)
        renderer = QSvgRenderer(QByteArray(svg.encode("utf-8")))
        from PySide6.QtGui import QPainter
        painter = QPainter(pix)
        renderer.render(painter)
        painter.end()
        return QIcon(pix)

    def stylesheet(self):
        c = self.COLORS
        return f"""
        QMainWindow, QWidget {{ background: {c['bg']}; color: {c['text']}; font-family: 'Segoe UI'; font-size: 10pt; }}
        QLabel {{ background: transparent; }}
        QFrame#Sidebar {{ background: {c['nav']}; border: none; }}
        QLabel#BrandName {{ color: #FFFFFF; font-size: 13pt; font-weight: 800; letter-spacing: 1px; }}
        QLabel#BrandSub {{ color: #9EABC2; font-size: 8pt; }}
        QLabel#PageTitle {{ color: {c['text']}; font-size: 21pt; font-weight: 750; }}
        QLabel#PageSub {{ color: {c['muted']}; font-size: 9pt; }}
        QLabel#CardTitle {{ color: {c['muted']}; font-size: 9pt; font-weight: 600; }}
        QLabel#Metric {{ color: {c['text']}; font-size: 22pt; font-weight: 750; }}
        QLabel#Tiny {{ color: {c['muted']}; font-size: 8pt; }}
        QFrame#Card, QGroupBox {{ background: {c['panel']}; border: 1px solid {c['line']}; border-radius: 14px; }}
        QGroupBox {{ margin-top: 12px; padding: 12px; font-weight: 700; }}
        QGroupBox::title {{ subcontrol-origin: margin; left: 14px; padding: 0 5px; color: {c['text']}; }}
        QPushButton {{ background: #FFFFFF; color: {c['text']}; border: 1px solid {c['line']}; border-radius: 9px; padding: 9px 14px; font-weight: 650; }}
        QPushButton:hover {{ border-color: {c['blue']}; color: {c['blue']}; background: {c['soft']}; }}
        QPushButton:disabled {{ color: #AAB3C1; background: #F1F3F6; }}
        QPushButton#Primary {{ background: {c['blue']}; color: white; border: 1px solid {c['blue']}; }}
        QPushButton#Primary:hover {{ background: #2459D8; }}
        QPushButton#Danger {{ color: {c['red']}; border-color: #F3D5D9; }}
        QPushButton#Nav {{ background: transparent; color: #AEBBD0; border: none; text-align: left; padding: 12px 14px; border-radius: 9px; font-weight: 600; }}
        QPushButton#Nav:hover {{ background: {c['nav2']}; color: white; }}
        QPushButton#Nav[active="true"] {{ background: #263D67; color: white; border-left: 3px solid #55B8FF; }}
        QComboBox, QSpinBox {{ background: #FFFFFF; border: 1px solid {c['line']}; border-radius: 8px; padding: 8px; min-height: 20px; }}
        QComboBox::drop-down {{ border: none; width: 24px; }}
        QTableWidget {{ background: white; alternate-background-color: #F8FAFD; border: 1px solid {c['line']}; border-radius: 10px; gridline-color: #EFF2F6; selection-background-color: #E8F0FF; selection-color: {c['text']}; }}
        QHeaderView::section {{ background: #F7F9FC; color: {c['muted']}; padding: 10px; border: none; border-bottom: 1px solid {c['line']}; font-weight: 700; }}
        QProgressBar {{ border: none; border-radius: 6px; background: #E9EEF6; height: 10px; text-align: center; color: transparent; }}
        QProgressBar::chunk {{ background: {c['blue']}; border-radius: 6px; }}
        QPlainTextEdit {{ background: #101B2D; color: #C9D7EA; border: none; border-radius: 10px; padding: 12px; font-family: Consolas; font-size: 9pt; }}
        QCheckBox {{ color: {c['text']}; spacing: 8px; }}
        """

    def build_ui(self):
        from PySide6.QtWidgets import QFrame, QStackedWidget, QSpacerItem, QSizePolicy
        from PySide6.QtGui import QPixmap, QPainter, QPen, QBrush, QColor
        root = QWidget()
        self.setCentralWidget(root)
        outer = QHBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(238)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(17, 22, 17, 18)
        side.setSpacing(9)

        # Official Unique Embedded Systems brand logo supplied by the user.
        brandrow = QHBoxLayout()
        brandrow.setContentsMargins(0, 0, 0, 0)
        logo = QLabel()
        logo_path = Path(__file__).with_name("Brand_Logo.png")
        if logo_path.exists():
            from PySide6.QtGui import QPixmap
            pixmap = QPixmap(str(logo_path))
            logo.setPixmap(pixmap.scaled(202, 88, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            logo.setText("UNIQUE EMBEDDED SYSTEMS")
            logo.setStyleSheet("color:#F9A817;font-size:11pt;font-weight:900;")
        logo.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        brandrow.addWidget(logo)
        side.addLayout(brandrow)
        side.addSpacing(25)
        section = QLabel("WORKSPACE")
        section.setStyleSheet("color:#71819B;font-size:8pt;font-weight:800;letter-spacing:1.4px;padding-left:8px;")
        side.addWidget(section)
        self.nav_buttons = []
        nav_defs = [
            ("overview", "Overview"), ("folder", "File Explorer"),
            ("upload", "AMR Upload"), ("terminal", "AT Communication Console"),
            ("settings", "AT Command Tester"), ("phone", "Call & SMS Tester"),
            ("signal", "Network Diagnostics"), ("check", "Automatic Test Suite")
        ]
        for idx, (ico, label) in enumerate(nav_defs):
            b = QPushButton("  " + label)
            b.setObjectName("Nav")
            b.setIcon(self.svg_icon(ico, "#B7C5D9", 19))
            b.setIconSize(QSize(19, 19))
            b.setProperty("active", idx == 0)
            b.clicked.connect(lambda checked=False, i=idx: self.switch_page(i))
            side.addWidget(b)
            self.nav_buttons.append(b)
        side.addStretch()
        divider = QFrame()
        divider.setFixedHeight(1)
        divider.setStyleSheet("background:#2A3852;border:none;")
        side.addWidget(divider)
        model = QLabel("CONNECTED DEVICE")
        model.setStyleSheet("color:#71819B;font-size:8pt;font-weight:800;letter-spacing:1.2px;padding:8px 4px 0;")
        side.addWidget(model)
        device = QLabel("◉  SIMCOM A7670C-LASS\n     Firmware  M6_V1.11.1")
        device.setStyleSheet("color:#D5DEEB;background:#172541;border-radius:9px;padding:12px;font-size:9pt;line-height:1.5;")
        side.addWidget(device)
        foot = QLabel("A7670C STUDIO  •  v1.2.4")
        foot.setStyleSheet("color:#64748B;font-size:8pt;padding:10px 4px 0;")
        side.addWidget(foot)
        outer.addWidget(sidebar)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(28, 22, 28, 20)
        content_layout.setSpacing(16)
        outer.addWidget(content, 1)

        top = QHBoxLayout()
        self.page_title = QLabel("Overview")
        self.page_title.setObjectName("PageTitle")
        top.addWidget(self.page_title)
        top.addStretch()
        self.connection_pill = QLabel("●  DISCONNECTED")
        self.connection_pill.setStyleSheet("background:#FFF2E8;color:#B96823;border-radius:12px;padding:8px 12px;font-size:8pt;font-weight:800;")
        top.addWidget(self.connection_pill)
        top.addSpacing(12)
        self.port = QComboBox()
        self.port.setMinimumWidth(190)
        top.addWidget(self.port)
        self.refresh_ports_btn = QPushButton()
        self.refresh_ports_btn.setIcon(self.svg_icon("refresh", "#53627A", 18))
        self.refresh_ports_btn.setToolTip("Refresh COM ports")
        self.refresh_ports_btn.setFixedWidth(42)
        top.addWidget(self.refresh_ports_btn)
        self.baud = QComboBox()
        self.baud.addItems(["115200", "921600", "460800", "230400", "57600"])
        top.addWidget(self.baud)
        self.profile = QComboBox()
        self.profile.addItems(["A7670C-LASS", "A7672S", "SIM7600", "SIM800"])
        self.profile.setToolTip("Profile selects the target modem family for diagnostics. EFS file operations remain A7670C-specific.")
        top.addWidget(self.profile)
        self.test_btn = QPushButton("Connect / Test")
        self.test_btn.setObjectName("Primary")
        self.test_btn.setIcon(self.svg_icon("plug", "#FFFFFF", 17))
        top.addWidget(self.test_btn)
        content_layout.addLayout(top)

        self.stack = QStackedWidget()
        content_layout.addWidget(self.stack, 1)
        self.build_overview_page()
        self.build_files_page()
        self.build_upload_page()
        self.build_console_page()
        self.build_at_tester_page()
        self.build_call_sms_page()
        self.build_network_page()
        self.build_auto_test_page()
        self.status = QLabel("Ready • Select the SIMCom USB AT port to begin • AT test tools support multiple SIMCom families")
        self.status.setObjectName("PageSub")
        content_layout.addWidget(self.status)

        self.refresh_ports_btn.clicked.connect(self.refresh_ports)
        self.test_btn.clicked.connect(self.test_at)
        self.stack.currentChanged.connect(self.page_changed)

    def make_card(self, title, value, detail, accent="#356DF3", icon_name="file"):
        from PySide6.QtWidgets import QFrame
        card = QFrame()
        card.setObjectName("Card")
        lay = QVBoxLayout(card)
        lay.setContentsMargins(17, 15, 17, 15)
        top = QHBoxLayout()
        lab = QLabel(title.upper())
        lab.setObjectName("CardTitle")
        top.addWidget(lab)
        top.addStretch()
        badge = QLabel()
        badge.setPixmap(self.svg_icon(icon_name, accent, 21).pixmap(21, 21))
        top.addWidget(badge)
        lay.addLayout(top)
        val = QLabel(value)
        val.setObjectName("Metric")
        lay.addWidget(val)
        desc = QLabel(detail)
        desc.setObjectName("Tiny")
        lay.addWidget(desc)
        return card, val, desc

    def build_overview_page(self):
        from PySide6.QtWidgets import QFrame
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 5, 0, 0)
        lay.setSpacing(16)
        intro = QHBoxLayout()
        left = QVBoxLayout()
        h = QLabel("Modem storage at a glance")
        h.setStyleSheet("font-size:15pt;font-weight:750;color:#17243B;")
        p = QLabel("Manage audio assets and files stored in your A7670C internal EFS.")
        p.setObjectName("PageSub")
        left.addWidget(h)
        left.addWidget(p)
        intro.addLayout(left)
        intro.addStretch()
        self.refresh_storage_btn = QPushButton("  Refresh storage")
        self.refresh_storage_btn.setIcon(self.svg_icon("refresh", "#356DF3", 17))
        intro.addWidget(self.refresh_storage_btn)
        lay.addLayout(intro)

        cards = QHBoxLayout()
        cards.setSpacing(13)
        self.total_card, self.total_value, self.total_desc = self.make_card("Total EFS", "—", "Internal storage capacity", "#356DF3", "database")
        self.used_card, self.used_value, self.used_desc = self.make_card("Used space", "—", "Space occupied by files", "#E39A35", "file")
        self.free_card, self.free_value, self.free_desc = self.make_card("Available space", "—", "Space available for uploads", "#18A874", "upload")
        for c in (self.total_card, self.used_card, self.free_card):
            cards.addWidget(c, 1)
        lay.addLayout(cards)

        storage = QFrame()
        storage.setObjectName("Card")
        sl = QVBoxLayout(storage)
        sl.setContentsMargins(20, 18, 20, 18)
        title = QLabel("STORAGE UTILIZATION")
        title.setObjectName("CardTitle")
        sl.addWidget(title)
        self.storage_bar = QProgressBar()
        self.storage_bar.setRange(0, 100)
        self.storage_bar.setValue(0)
        self.storage_bar.setFormat("")
        self.storage_bar.setFixedHeight(13)
        sl.addWidget(self.storage_bar)
        legend = QHBoxLayout()
        self.storage_summary = QLabel("Connect to the modem and refresh storage to read EFS usage.")
        self.storage_summary.setObjectName("Tiny")
        legend.addWidget(self.storage_summary)
        legend.addStretch()
        self.storage_percent = QLabel("—")
        self.storage_percent.setStyleSheet("font-size:11pt;font-weight:800;color:#17243B;")
        legend.addWidget(self.storage_percent)
        sl.addLayout(legend)
        lay.addWidget(storage)

        quick = QHBoxLayout()
        quick.setSpacing(13)
        for ico, title, desc, page_idx in [
            ("folder", "Browse files", "View and remove modem files", 1),
            ("upload", "Upload audio", "Send AMR files to EFS", 2),
            ("terminal", "AT console", "Inspect modem responses", 3)]:
            box = QFrame()
            box.setObjectName("Card")
            bl = QVBoxLayout(box)
            bl.setContentsMargins(17, 16, 17, 16)
            row = QHBoxLayout()
            icon = QLabel()
            icon.setPixmap(self.svg_icon(ico, "#356DF3", 23).pixmap(23, 23))
            row.addWidget(icon)
            row.addStretch()
            bl.addLayout(row)
            t = QLabel(title)
            t.setStyleSheet("font-size:12pt;font-weight:750;")
            d = QLabel(desc)
            d.setObjectName("Tiny")
            bl.addWidget(t)
            bl.addWidget(d)
            btn = QPushButton("Open  →")
            btn.clicked.connect(lambda checked=False, i=page_idx: self.switch_page(i))
            bl.addWidget(btn)
            quick.addWidget(box, 1)
        lay.addLayout(quick)
        lay.addStretch()
        self.stack.addWidget(page)
        self.refresh_storage_btn.clicked.connect(self.refresh_storage)

    def build_files_page(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 5, 0, 0)
        heading = QHBoxLayout()
        labels = QVBoxLayout()
        h = QLabel("EFS File Explorer")
        h.setStyleSheet("font-size:15pt;font-weight:750;")
        sub = QLabel("Files found in modem storage C:/")
        sub.setObjectName("PageSub")
        labels.addWidget(h)
        labels.addWidget(sub)
        heading.addLayout(labels)
        heading.addStretch()
        self.remote_count = QLabel("0 files")
        self.remote_count.setObjectName("PageSub")
        heading.addWidget(self.remote_count)
        self.refresh_files_btn = QPushButton("Refresh list")
        self.refresh_files_btn.setIcon(self.svg_icon("refresh", "#356DF3", 17))
        heading.addWidget(self.refresh_files_btn)
        self.delete_btn = QPushButton("Delete selected")
        self.delete_btn.setObjectName("Danger")
        self.delete_btn.setIcon(self.svg_icon("trash", "#E05260", 17))
        heading.addWidget(self.delete_btn)
        lay.addLayout(heading)
        self.remote_table = QTableWidget(0, 3)
        self.remote_table.setHorizontalHeaderLabels(["FILE NAME", "STORAGE LOCATION", "TYPE"])
        self.remote_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.remote_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.remote_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.remote_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.remote_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.remote_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.remote_table.setAlternatingRowColors(True)
        lay.addWidget(self.remote_table, 1)
        hint = QLabel("Tip: Select one or more rows, then choose Delete selected. Deletion is permanent.")
        hint.setObjectName("Tiny")
        lay.addWidget(hint)
        self.stack.addWidget(page)
        self.refresh_files_btn.clicked.connect(self.refresh_storage)
        self.delete_btn.clicked.connect(self.delete_selected)

    def build_upload_page(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 5, 0, 0)
        header = QHBoxLayout()
        labels = QVBoxLayout()
        h = QLabel("Upload Center")
        h.setStyleSheet("font-size:15pt;font-weight:750;")
        sub = QLabel("Queue AMR audio files and transfer them to modem EFS.")
        sub.setObjectName("PageSub")
        labels.addWidget(h)
        labels.addWidget(sub)
        header.addLayout(labels)
        header.addStretch()
        self.add_btn = QPushButton("  Add AMR files")
        self.add_btn.setIcon(self.svg_icon("music", "#356DF3", 18))
        self.add_btn.setObjectName("Primary")
        header.addWidget(self.add_btn)
        self.remove_local_btn = QPushButton("Remove from queue")
        header.addWidget(self.remove_local_btn)
        self.clear_btn = QPushButton("Clear queue")
        header.addWidget(self.clear_btn)
        lay.addLayout(header)

        self.local_table = QTableWidget(0, 3)
        self.local_table.setHorizontalHeaderLabels(["LOCAL AUDIO FILE", "FILE SIZE", "TRANSFER STATUS"])
        self.local_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.local_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.local_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.local_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.local_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.local_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.local_table.setAlternatingRowColors(True)
        lay.addWidget(self.local_table, 1)

        settings = QFrame()
        settings.setObjectName("Card")
        st = QHBoxLayout(settings)
        st.setContentsMargins(16, 13, 16, 13)
        self.overwrite = QCheckBox("Replace files with the same name")
        st.addWidget(self.overwrite)
        st.addStretch()
        st.addWidget(QLabel("Chunk size"))
        self.chunk = QSpinBox()
        self.chunk.setRange(64, 2048)
        self.chunk.setValue(256)
        st.addWidget(self.chunk)
        st.addWidget(QLabel("Delay (ms)"))
        self.delay = QSpinBox()
        self.delay.setRange(0, 1000)
        self.delay.setValue(50)
        st.addWidget(self.delay)
        lay.addWidget(settings)

        bottom = QHBoxLayout()
        self.upload_progress = QProgressBar()
        self.upload_progress.setValue(0)
        self.upload_progress.setFormat("Transfer progress  %p%")
        bottom.addWidget(self.upload_progress, 1)
        self.upload_btn = QPushButton("  Start upload")
        self.upload_btn.setObjectName("Primary")
        self.upload_btn.setIcon(self.svg_icon("upload", "#FFFFFF", 18))
        self.upload_btn.setMinimumWidth(160)
        bottom.addWidget(self.upload_btn)
        lay.addLayout(bottom)
        self.stack.addWidget(page)

        self.add_btn.clicked.connect(self.add_amr)
        self.remove_local_btn.clicked.connect(self.remove_local)
        self.clear_btn.clicked.connect(self.clear_queue)
        self.upload_btn.clicked.connect(self.upload_queue)

    def build_console_page(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 5, 0, 0)
        h = QLabel("AT Communication Console")
        h.setStyleSheet("font-size:15pt;font-weight:750;")
        sub = QLabel("Live command and response log from the SIMCom USB AT interface.")
        sub.setObjectName("PageSub")
        lay.addWidget(h)
        lay.addWidget(sub)
        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumBlockCount(4000)
        lay.addWidget(self.log_box, 1)
        row = QHBoxLayout()
        note = QLabel("The manager logs AT commands used by its operations.")
        note.setObjectName("Tiny")
        row.addWidget(note)
        row.addStretch()
        clearlog = QPushButton("Clear log")
        clearlog.clicked.connect(self.log_box.clear)
        row.addWidget(clearlog)
        lay.addLayout(row)
        self.stack.addWidget(page)

    def build_at_tester_page(self):
        from PySide6.QtWidgets import QLineEdit
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 5, 0, 0)
        title = QLabel("AT Command Tester")
        title.setStyleSheet("font-size:15pt;font-weight:750;")
        sub = QLabel("Send manual AT commands and inspect the raw modem response. Avoid reset, firmware, or radio-band commands unless you understand their impact.")
        sub.setObjectName("PageSub")
        lay.addWidget(title)
        lay.addWidget(sub)

        presets = QHBoxLayout()
        self.at_preset = QComboBox()
        self.at_preset.addItems([
            "Select preset command", "AT", "ATI", "AT+CPIN?", "AT+CSQ",
            "AT+CEREG?", "AT+COPS?", "AT+GSN", "AT+CCID", "AT+CBC",
            "AT+CGATT?", "AT+CGDCONT?"
        ])
        presets.addWidget(self.at_preset, 1)
        use_preset = QPushButton("Use preset")
        use_preset.clicked.connect(lambda: self.at_input.setText(self.at_preset.currentText() if self.at_preset.currentIndex() else ""))
        presets.addWidget(use_preset)
        lay.addLayout(presets)

        row = QHBoxLayout()
        self.at_input = QLineEdit()
        self.at_input.setPlaceholderText("Enter AT command, e.g. AT+CSQ")
        row.addWidget(self.at_input, 1)
        self.at_send_btn = QPushButton("Send command")
        self.at_send_btn.setObjectName("Primary")
        self.at_send_btn.clicked.connect(self.send_manual_at)
        row.addWidget(self.at_send_btn)
        lay.addLayout(row)

        self.at_output = QPlainTextEdit()
        self.at_output.setReadOnly(True)
        self.at_output.setPlaceholderText("Command responses will appear here…")
        lay.addWidget(self.at_output, 1)
        self.stack.addWidget(page)

    def build_call_sms_page(self):
        from PySide6.QtWidgets import QGridLayout
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 5, 0, 0)
        lay.setSpacing(14)

        title = QLabel("Call & SMS Tester")
        title.setStyleSheet("font-size:15pt;font-weight:750;")
        sub = QLabel("Mobile-style dialer and SMS console for SIMCom modem testing.")
        sub.setObjectName("PageSub")
        lay.addWidget(title)
        lay.addWidget(sub)

        panels = QHBoxLayout()
        panels.setSpacing(14)

        # Phone dialer panel
        call_card = QFrame()
        call_card.setObjectName("Card")
        call_card.setMinimumWidth(340)
        cl = QVBoxLayout(call_card)
        cl.setContentsMargins(20, 18, 20, 18)
        cl.setSpacing(10)

        phone_head = QLabel("PHONE")
        phone_head.setStyleSheet("font-size:9pt;font-weight:800;letter-spacing:1.4px;color:#7B879B;")
        cl.addWidget(phone_head)

        self.call_number = QLineEdit()
        self.call_number.setAlignment(Qt.AlignCenter)
        self.call_number.setPlaceholderText("Enter phone number")
        self.call_number.setMinimumHeight(48)
        self.call_number.setStyleSheet("font-size:17pt;font-weight:650;padding:10px;border:1px solid #DCE3ED;border-radius:12px;background:#F9FBFE;")
        cl.addWidget(self.call_number)

        keypad = QGridLayout()
        keypad.setSpacing(8)
        keypad_labels = [
            ("1", "2", "3"), ("4", "5", "6"),
            ("7", "8", "9"), ("*", "0", "#")
        ]
        for row_idx, row_values in enumerate(keypad_labels):
            for col_idx, digit in enumerate(row_values):
                key = QPushButton(digit)
                key.setMinimumHeight(43)
                key.setStyleSheet("QPushButton{font-size:15pt;font-weight:650;background:#F3F6FB;border:1px solid #E3E9F1;border-radius:12px;color:#17243B;} QPushButton:hover{background:#FFF4D9;border-color:#F9A817;}")
                key.clicked.connect(lambda checked=False, d=digit: self.call_number.setText(self.call_number.text() + d))
                keypad.addWidget(key, row_idx, col_idx)
        cl.addLayout(keypad)

        call_actions = QHBoxLayout()
        self.dial_btn = QPushButton("☎  CALL")
        self.dial_btn.setMinimumHeight(46)
        self.dial_btn.setStyleSheet("QPushButton{background:#18A874;color:white;border:0;border-radius:22px;font-weight:800;padding:10px 18px;} QPushButton:hover{background:#13865D;}")
        self.dial_btn.clicked.connect(self.start_dial)
        call_actions.addWidget(self.dial_btn, 1)

        self.hangup_btn = QPushButton("■  END")
        self.hangup_btn.setMinimumHeight(46)
        self.hangup_btn.setStyleSheet("QPushButton{background:#E05260;color:white;border:0;border-radius:22px;font-weight:800;padding:10px 18px;} QPushButton:hover{background:#C63D4B;}")
        self.hangup_btn.clicked.connect(lambda: self.start_job("hangup"))
        call_actions.addWidget(self.hangup_btn, 1)
        cl.addLayout(call_actions)

        self.call_status_btn = QPushButton("Check call status")
        self.call_status_btn.clicked.connect(lambda: self.start_job("call_status"))
        cl.addWidget(self.call_status_btn)
        clear_number = QPushButton("Clear number")
        clear_number.clicked.connect(self.call_number.clear)
        cl.addWidget(clear_number)
        panels.addWidget(call_card, 1)

        # SMS composer / inbox panel
        sms_card = QFrame()
        sms_card.setObjectName("Card")
        sl = QVBoxLayout(sms_card)
        sl.setContentsMargins(20, 18, 20, 18)
        sl.setSpacing(10)

        sms_head_row = QHBoxLayout()
        sms_head = QLabel("MESSAGES")
        sms_head.setStyleSheet("font-size:9pt;font-weight:800;letter-spacing:1.4px;color:#7B879B;")
        sms_head_row.addWidget(sms_head)
        sms_head_row.addStretch()
        self.sms_read_btn = QPushButton("↻  Read inbox")
        self.sms_read_btn.clicked.connect(lambda: self.start_job("read_sms"))
        sms_head_row.addWidget(self.sms_read_btn)
        sl.addLayout(sms_head_row)

        self.sms_number = QLineEdit()
        self.sms_number.setPlaceholderText("To: +91XXXXXXXXXX")
        self.sms_number.setMinimumHeight(42)
        sl.addWidget(self.sms_number)

        self.sms_message = QPlainTextEdit()
        self.sms_message.setPlaceholderText("Type your SMS message here…")
        self.sms_message.setMinimumHeight(145)
        self.sms_message.setStyleSheet("QPlainTextEdit{background:#F7F9FC;border:1px solid #E3E9F1;border-radius:12px;padding:12px;font-size:10pt;}")
        sl.addWidget(self.sms_message, 1)

        sms_bottom = QHBoxLayout()
        sms_hint = QLabel("SMS will be sent using the selected SIM.")
        sms_hint.setObjectName("Tiny")
        sms_bottom.addWidget(sms_hint, 1)
        self.sms_send_btn = QPushButton("➤  SEND SMS")
        self.sms_send_btn.setMinimumHeight(44)
        self.sms_send_btn.setStyleSheet("QPushButton{background:#F9A817;color:white;border:0;border-radius:12px;font-weight:800;padding:10px 18px;} QPushButton:hover{background:#E29308;}")
        self.sms_send_btn.clicked.connect(self.send_sms_now)
        sms_bottom.addWidget(self.sms_send_btn)
        sl.addLayout(sms_bottom)

        self.sms_output = QPlainTextEdit()
        self.sms_output.setReadOnly(True)
        self.sms_output.setMaximumHeight(115)
        self.sms_output.setPlaceholderText("Inbox messages and SMS results will appear here…")
        sl.addWidget(self.sms_output)
        panels.addWidget(sms_card, 1)
        lay.addLayout(panels, 1)
        self.stack.addWidget(page)

    def build_network_page(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 5, 0, 0)
        title = QLabel("Network & SIM Diagnostics")
        title.setStyleSheet("font-size:15pt;font-weight:750;")
        sub = QLabel("Queries SIM readiness, signal quality, registration, operator, packet attachment and PDP context.")
        sub.setObjectName("PageSub")
        lay.addWidget(title)
        lay.addWidget(sub)
        row = QHBoxLayout()
        self.network_run_btn = QPushButton("Run diagnostics")
        self.network_run_btn.setObjectName("Primary")
        self.network_run_btn.clicked.connect(lambda: self.start_job("network"))
        row.addWidget(self.network_run_btn)
        row.addStretch()
        lay.addLayout(row)
        self.network_output = QPlainTextEdit()
        self.network_output.setReadOnly(True)
        self.network_output.setPlaceholderText("Network diagnostic results will appear here…")
        lay.addWidget(self.network_output, 1)
        self.stack.addWidget(page)

    def build_auto_test_page(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 5, 0, 0)
        title = QLabel("Automatic Modem Test Suite")
        title.setStyleSheet("font-size:15pt;font-weight:750;")
        sub = QLabel("Runs read-only modem, SIM and network checks. Voice and SMS tests remain manual and require confirmation.")
        sub.setObjectName("PageSub")
        lay.addWidget(title)
        lay.addWidget(sub)
        actions = QHBoxLayout()
        self.auto_test_btn = QPushButton("Run automatic test")
        self.auto_test_btn.setObjectName("Primary")
        self.auto_test_btn.clicked.connect(self.run_auto_test)
        actions.addWidget(self.auto_test_btn)
        self.report_btn = QPushButton("Export PDF report")
        self.report_btn.clicked.connect(self.export_test_report)
        self.report_btn.setEnabled(False)
        actions.addWidget(self.report_btn)
        self.auto_summary = QLabel("No test run yet")
        self.auto_summary.setObjectName("PageSub")
        actions.addStretch()
        actions.addWidget(self.auto_summary)
        lay.addLayout(actions)
        self.auto_table = QTableWidget(0, 4)
        self.auto_table.setHorizontalHeaderLabels(["Test", "AT command", "Result", "Details"])
        self.auto_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.auto_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.auto_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.auto_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.auto_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.auto_table.setAlternatingRowColors(True)
        lay.addWidget(self.auto_table, 1)
        note = QLabel("Note: Network registration and packet attachment depend on SIM activation, coverage and carrier provisioning. Internet browsing is not asserted by these AT checks; APN/PDP data-session testing is a separate next step.")
        note.setWordWrap(True)
        note.setObjectName("PageSub")
        lay.addWidget(note)
        self.auto_test_data = []
        self.auto_test_time = None
        self.stack.addWidget(page)

    def run_auto_test(self):
        if not self.current_port():
            QMessageBox.warning(self, "No AT port", "Select the SIMCom USB AT COM port first.")
            return
        self.auto_table.setRowCount(0)
        self.auto_test_data = []
        self.auto_test_time = datetime.datetime.now().astimezone()
        self.auto_summary.setText("Test running…")
        self.report_btn.setEnabled(False)
        self.start_job("auto_test")

    def update_auto_test_results(self, checks):
        self.auto_test_data = checks
        self.auto_table.setRowCount(0)
        for item in checks:
            row = self.auto_table.rowCount()
            self.auto_table.insertRow(row)
            for col, value in enumerate((item["name"], item["command"], item["status"], item["detail"])):
                cell = QTableWidgetItem(str(value))
                if col == 2:
                    cell.setForeground(QColor("#14845D" if value == "PASS" else "#D04452"))
                self.auto_table.setItem(row, col, cell)
        passed = sum(1 for x in checks if x["status"] == "PASS")
        self.auto_summary.setText(f"{passed}/{len(checks)} checks passed")

    def export_test_report(self):
        if not self.auto_test_data:
            QMessageBox.information(self, "No test results", "Run the automatic test suite before exporting a report.")
            return
        default_name = "UES_A7670C_Test_Report_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S") + ".pdf"
        path, _ = QFileDialog.getSaveFileName(self, "Save UES test report", default_name, "PDF report (*.pdf)")
        if not path:
            return
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        from PySide6.QtGui import QTextDocument
        from PySide6.QtPrintSupport import QPrinter
        from html import escape
        passed = sum(1 for x in self.auto_test_data if x["status"] == "PASS")
        total = len(self.auto_test_data)
        overall = "PASS" if passed == total else "PARTIAL / FAIL"
        rows = "".join(
            "<tr><td>{}</td><td><code>{}</code></td><td style='color:{};font-weight:bold'>{}</td><td>{}</td></tr>".format(
                escape(x["name"]), escape(x["command"]), "#14845D" if x["status"] == "PASS" else "#D04452",
                escape(x["status"]), escape(x["detail"])) for x in self.auto_test_data)
        when = self.auto_test_time.strftime("%Y-%m-%d %H:%M:%S %Z") if self.auto_test_time else "Not recorded"
        html_doc = f"<html><head><style>body{{font-family:Arial;color:#17243B;font-size:10pt}}h1{{color:#10213B}}.brand{{color:#E39A00;font-weight:bold}}table{{width:100%;border-collapse:collapse}}th{{background:#10213B;color:white}}td,th{{border:1px solid #DCE3EC;padding:7px;text-align:left}}.meta{{background:#F3F6FB;padding:10px}}</style></head><body><p class='brand'>UNIQUE EMBEDDED SYSTEMS PVT LTD</p><h1>A7670C Studio – Automatic Modem Test Report</h1><div class='meta'><b>Test date:</b> {escape(when)}<br><b>COM port:</b> {escape(str(self.current_port() or 'N/A'))}<br><b>Baud rate:</b> {escape(self.baud.currentText())}<br><b>Selected profile:</b> {escape(self.profile.currentText())}<br><b>Overall:</b> {overall} ({passed}/{total} checks passed)</div><h2>Test results</h2><table><tr><th>Test</th><th>Command</th><th>Status</th><th>Details</th></tr>{rows}</table><p><b>Important:</b> This report records AT-command responses only. It does not certify RF performance, internet reachability, voice-call completion or SMS delivery. Carrier and SIM conditions can affect registration results.</p><p>Generated by UES A7670C Studio.</p></body></html>"
        doc = QTextDocument()
        doc.setHtml(html_doc)
        printer = QPrinter(QPrinter.HighResolution)
        printer.setOutputFormat(QPrinter.PdfFormat)
        printer.setOutputFileName(path)
        doc.print_(printer)
        QMessageBox.information(self, "Report exported", "PDF report saved successfully:\n" + path)

    def send_manual_at(self):
        command = self.at_input.text().strip()
        if not command:
            return
        self.at_output.appendPlainText(f">>> {command}")
        self.start_job("raw", command)

    def start_dial(self):
        number = self.call_number.text().strip()
        if not number:
            QMessageBox.warning(self, "Phone number required", "Enter the destination number before dialing.")
            return
        answer = QMessageBox.question(self, "Confirm outgoing call",
            f"Place an outgoing call to {number}?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer == QMessageBox.Yes:
            self.start_job("dial", number)

    def send_sms_now(self):
        number = self.sms_number.text().strip()
        message = self.sms_message.toPlainText().strip()
        if not number or not message:
            QMessageBox.warning(self, "SMS details required", "Enter a recipient number and message.")
            return
        answer = QMessageBox.question(self, "Confirm SMS",
            f"Send this SMS to {number}?\\n\\n{message}",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer == QMessageBox.Yes:
            self.start_job("send_sms", (number, message))

    def switch_page(self, index):
        self.stack.setCurrentIndex(index)
        for i, b in enumerate(self.nav_buttons):
            b.setProperty("active", i == index)
            b.style().unpolish(b)
            b.style().polish(b)
        page_titles = [
            "Overview", "File Explorer", "AMR Upload",
            "AT Communication Console", "AT Command Tester",
            "Call & SMS Tester", "Network Diagnostics", "Automatic Test Suite"
        ]
        self.page_title.setText(page_titles[index])
        if index == 1:
            self.refresh_storage()

    def page_changed(self, index):
        self.current_page = index

    def log(self, message):
        self.log_box.appendPlainText(time.strftime("[%H:%M:%S] ") + str(message))

    def refresh_ports(self):
        previous = self.port.currentData()
        self.port.clear()
        for p in list_ports.comports():
            self.port.addItem(f"{p.device}  ·  {p.description}", p.device)
        if previous:
            idx = self.port.findData(previous)
            if idx >= 0:
                self.port.setCurrentIndex(idx)
        if self.port.count() == 0:
            self.port.addItem("No serial ports found", None)

    def current_port(self):
        return self.port.currentData()

    def busy(self, state):
        widgets = [self.refresh_ports_btn, self.test_btn, self.refresh_storage_btn,
                   self.refresh_files_btn, self.delete_btn, self.add_btn,
                   self.remove_local_btn, self.clear_btn, self.upload_btn,
                   self.port, self.baud, self.profile, self.chunk, self.delay, self.overwrite,
                   self.at_send_btn, self.dial_btn, self.hangup_btn, self.call_status_btn,
                   self.sms_send_btn, self.sms_read_btn, self.network_run_btn, self.auto_test_btn, self.report_btn]
        for widget in widgets:
            if hasattr(self, widget.objectName()):
                pass
            widget.setEnabled(not state)

    def start_job(self, action, payload=None):
        if self.job and self.job.isRunning():
            return
        port = self.current_port()
        if not port:
            QMessageBox.warning(self, "No AT port", "Select the SIMCom USB AT COM port.")
            return
        self.busy(True)
        self.job = Job(port, int(self.baud.currentText()), action, payload,
                       self.overwrite.isChecked(), self.chunk.value(), self.delay.value())
        self.job.log.connect(self.log)
        self.job.status.connect(self.status.setText)
        self.job.files_ready.connect(self.populate_remote)
        self.job.memory_ready.connect(self.show_memory)
        self.job.upload_progress.connect(self.update_upload_progress)
        self.job.item_done.connect(self.item_done)
        self.job.done.connect(self.job_done)
        self.job.test_results.connect(self.update_auto_test_results)
        self.job.start()

    def test_at(self):
        self.start_job("connect")

    def refresh_storage(self):
        self.start_job("refresh")

    def populate_remote(self, names):
        self.remote_files = names
        self.remote_table.setRowCount(0)
        for name in names:
            r = self.remote_table.rowCount()
            self.remote_table.insertRow(r)
            self.remote_table.setItem(r, 0, QTableWidgetItem(name))
            self.remote_table.setItem(r, 1, QTableWidgetItem("C:/"))
            self.remote_table.setItem(r, 2, QTableWidgetItem(Path(name).suffix.upper().lstrip(".") or "FILE"))
        self.remote_count.setText(f"{len(names)} file(s) in C:/")

    def show_memory(self, info):
        if not info:
            self.total_value.setText("N/A")
            self.used_value.setText("N/A")
            self.free_value.setText("N/A")
            self.storage_summary.setText("FSMEM response not recognized by this firmware.")
            self.storage_percent.setText("—")
            self.storage_bar.setValue(0)
            return
        total, used, free = info
        pct = int(used * 100 / total) if total else 0
        self.total_value.setText(self.human(total))
        self.used_value.setText(self.human(used))
        self.free_value.setText(self.human(free))
        self.total_desc.setText(f"{total:,} bytes reported by modem")
        self.used_desc.setText(f"{pct}% of EFS capacity")
        self.free_desc.setText("Available for new files")
        self.storage_bar.setValue(pct)
        self.storage_summary.setText(f"{self.human(used)} used  •  {self.human(free)} available")
        self.storage_percent.setText(f"{pct}% used")

    @staticmethod
    def human(n):
        units = ["B", "KB", "MB", "GB"]
        value = float(n)
        for unit in units:
            if value < 1024 or unit == units[-1]:
                return f"{value:.2f} {unit}"
            value /= 1024
        return f"{n} B"

    def delete_selected(self):
        rows = sorted({i.row() for i in self.remote_table.selectedIndexes()})
        names = [self.remote_table.item(r, 0).text() for r in rows]
        if not names:
            QMessageBox.information(self, "Select files", "Select one or more modem files to delete.")
            return
        answer = QMessageBox.warning(self, "Confirm deletion",
            "Permanently delete these modem file(s)?\n\n" + "\n".join(names),
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer == QMessageBox.Yes:
            self.start_job("delete", names)

    def add_amr(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Choose AMR files", "", "AMR audio (*.amr)"
        )
        for path in paths:
            if Path(path).suffix.lower() != ".amr":
                QMessageBox.warning(self, "Unsupported file", "Only .amr files can be added.")
                continue
            if path not in self.local_files:
                self.local_files.append(path)
                r = self.local_table.rowCount()
                self.local_table.insertRow(r)
                self.local_table.setItem(r, 0, QTableWidgetItem(Path(path).name))
                self.local_table.setItem(r, 1, QTableWidgetItem(self.human(os.path.getsize(path))))
                self.local_table.setItem(r, 2, QTableWidgetItem("Queued"))

    def remove_local(self):
        rows = sorted({i.row() for i in self.local_table.selectedIndexes()}, reverse=True)
        for r in rows:
            self.local_files.pop(r)
            self.local_table.removeRow(r)

    def clear_queue(self):
        if self.job and self.job.isRunning():
            return
        self.local_files.clear()
        self.local_table.setRowCount(0)

    def upload_queue(self):
        if not self.local_files:
            QMessageBox.information(self, "No AMR files", "Add AMR files to the upload queue first.")
            return
        non_amr = [Path(item).name for item in self.local_files if Path(item).suffix.lower() != ".amr"]
        if non_amr:
            QMessageBox.warning(self, "Unsupported file type",
                "Only AMR files are supported by this upload queue:\n\n" + "\n".join(non_amr))
            return
        answer = QMessageBox.question(self, "Confirm upload",
            f"Upload {len(self.local_files)} AMR file(s) to modem storage C:/?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer == QMessageBox.Yes:
            for r in range(self.local_table.rowCount()):
                self.local_table.setItem(r, 2, QTableWidgetItem("Queued"))
            self.start_job("upload", list(self.local_files))

    def update_upload_progress(self, value):
        self.upload_progress.setValue(value)

    def item_done(self, item, ok, detail):
        if item in self.local_files:
            r = self.local_files.index(item)
            self.local_table.setItem(r, 2, QTableWidgetItem("Uploaded" if ok else "Failed"))
        self.log(f"{'SUCCESS' if ok else 'FAILED'}: {item} — {detail}")

    def job_done(self, message, result):
        self.busy(False)
        if message != "OK":
            self.status.setText("Operation error: " + message)
            self.connection_pill.setText("●  CHECK CONNECTION")
            self.connection_pill.setStyleSheet("background:#FFF2E8;color:#B96823;border-radius:12px;padding:8px 12px;font-size:8pt;font-weight:800;")
        else:
            self.status.setText("Ready • Last modem operation completed")
            if self.current_page == 0:
                self.connection_pill.setText("●  MODEM RESPONDING")
                self.connection_pill.setStyleSheet("background:#E7F8F0;color:#14845D;border-radius:12px;padding:8px 12px;font-size:8pt;font-weight:800;")
        self.upload_progress.setValue(0)
        if result is not None:
            rendered = str(result).strip()
            if self.current_page == 4:
                self.at_output.appendPlainText(rendered)
            elif self.current_page == 5:
                if hasattr(self, "sms_output"):
                    self.sms_output.appendPlainText(rendered)
                self.log("CALL/SMS RESULT:\\n" + rendered)
            elif self.current_page == 6:
                self.network_output.setPlainText(rendered)
            elif self.current_page == 7 and isinstance(result, list):
                self.update_auto_test_results(result)
                self.report_btn.setEnabled(True)
        if message == "OK":
            self.log("Operation completed.")

    def closeEvent(self, event):
        if self.job and self.job.isRunning():
            QMessageBox.warning(self, "Busy", "Wait for the modem operation to finish.")
            event.ignore()
        else:
            event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    base_dir = Path(__file__).resolve().parent
    logo_path = base_dir / "Brand_Logo.png"
    icon_path = base_dir / "unique_embedded_icon.ico"
    app.setWindowIcon(QIcon(str(icon_path if icon_path.exists() else logo_path)))

    splash = AnimatedSplash(logo_path)
    splash.show()

    def launch_main_window():
        try:
            win = MainWindow()
            win.setWindowIcon(QIcon(str(icon_path if icon_path.exists() else logo_path)))
            win.show()
            win.raise_()
            win.activateWindow()
            splash.timer.stop()
            splash.finish(win)
            app.main_window = win
        except Exception as exc:
            splash.timer.stop()
            QMessageBox.critical(
                None,
                "UES A7670C Studio startup error",
                "The main application could not be initialized:\\n\\n" + str(exc)
            )
            app.quit()

    # Allow the splash animation to play, then initialize and show the app.
    QTimer.singleShot(1800, launch_main_window)
    sys.exit(app.exec())
