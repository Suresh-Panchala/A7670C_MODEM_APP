#define MyAppName "UES A7670C Studio"
#define MyAppVersion "1.2.4"
#define MyAppPublisher "Unique Embedded Systems Pvt Ltd"
#define MyAppExeName "UES A7670C Studio.exe"

[Setup]
AppId={{D7F3A1C2-8D4A-4F1A-9B63-7E5A7670C110}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Unique Embedded Systems\UES A7670C Studio
DefaultGroupName={#MyAppName}
OutputDir=installer
OutputBaseFilename=UES_A7670C_Studio_Setup
SetupIconFile=unique_embedded_icon.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
ArchitecturesInstallIn64BitMode=x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"; Flags: unchecked

[Files]
Source: "dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: postinstall nowait skipifsilent
