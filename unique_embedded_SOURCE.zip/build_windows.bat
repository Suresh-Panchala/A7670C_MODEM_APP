@echo off
setlocal
cd /d "%~dp0"

echo =====================================================
echo  UNIQUE EMBEDDED SYSTEMS - UES A7670C STUDIO
echo  Build Windows application AND installable setup
echo =====================================================
echo.

where py >nul 2>&1
if errorlevel 1 (
  echo Python launcher "py" was not found. Install Python 3.10+ first.
  goto error
)

echo [1/4] Installing build dependencies...
py -m pip install --upgrade pip
if errorlevel 1 goto error
py -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto error

echo.
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "UES A7670C Studio.spec" del /q "UES A7670C Studio.spec"

echo [2/4] Building the Windows application...
py -m PyInstaller --noconfirm --clean --windowed --onefile --name "UES A7670C Studio" --icon "unique_embedded_icon.ico" --add-data "Brand_Logo.png;." a7670c_efs_manager.py
if errorlevel 1 goto error

if not exist "dist\UES A7670C Studio.exe" (
  echo The application EXE was not created.
  goto error
)

echo.
echo [3/4] Looking for Inno Setup 6 compiler...
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC (
  for %%I in (ISCC.exe) do set "ISCC=%%~$PATH:I"
)

if not defined ISCC (
  echo.
  echo PORTABLE EXE BUILD SUCCEEDED, but Inno Setup 6 was not found.
  echo To create the normal Windows installer:
  echo   1. Install Inno Setup 6 from https://jrsoftware.org/isinfo.php
  echo   2. Run this build_windows.bat again.
  echo.
  echo Portable EXE: %CD%\dist\UES A7670C Studio.exe
  pause
  exit /b 0
)

echo.
echo [4/4] Creating the installable Windows setup...
if not exist "installer" mkdir installer
"%ISCC%" "UES_A7670C_Studio_Setup.iss"
if errorlevel 1 goto error

if not exist "installer\UES_A7670C_Studio_Setup.exe" (
  echo Inno Setup did not create the expected installer.
  goto error
)

echo.
echo =====================================================
echo  SUCCESS - INSTALLER CREATED
echo  %CD%\installer\UES_A7670C_Studio_Setup.exe
echo =====================================================
echo.
echo Run this Setup.exe to install UES A7670C Studio like a
echo normal Windows application. It creates Start Menu and
echo Uninstall entries. Desktop shortcut is selectable.
pause
exit /b 0

:error
echo.
echo BUILD FAILED. Please copy the complete error text.
pause
exit /b 1
